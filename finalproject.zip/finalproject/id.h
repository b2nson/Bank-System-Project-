//
// Created by Benson Nguyen on 5/2/23.
//

#ifndef FINALPROJECT_ID_H
#define FINALPROJECT_ID_H

class Id {
private:
    int id;
public:

    const void setId(const int toId) { this->id = toId; }

    const int getId() { return id; }
};

#endif
